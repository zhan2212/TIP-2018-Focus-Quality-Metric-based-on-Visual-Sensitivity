

load score_subjective;
load score_objective;
yy=score_subjective;
zz=score_objective; 
[delta,beta,x,y,diff]=findrmse5(zz,yy,'','Proposed Method', 'DMOS',1,[50  80  70]/255,'',1.5:0.5:5,1.5:0.5:5,'.');
CID_cc(01,:)=[corr(x,y),corr(x,y,'type','spearman'),corr(x,y,'type','kendall'),(mean(diff.^2))^0.5];
plcc=CID_cc(1)
srcc=CID_cc(2)
krcc=CID_cc(3)
rmse=CID_cc(4)
